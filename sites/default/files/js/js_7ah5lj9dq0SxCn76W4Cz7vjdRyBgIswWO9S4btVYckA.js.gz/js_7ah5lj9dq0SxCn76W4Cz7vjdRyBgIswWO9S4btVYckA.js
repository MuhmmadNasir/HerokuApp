(function($){

$(document).ready(function(){

$('#block-devel-switch-user').css('cursor','pointer').click(function(){
   $('ul.links').slideToggle();




$('.field-items').hover(function(){
$(this).addClass('hilight');
},
function(){
$(this).removeClass('hilight');
}
);




 });


 });

})(jQuery);


;
