(function($){

jQuery(document).ready(function(){

alert("welcome");



 });

})(jQuery);


;
(function($){

jQuery(document).ready(function(){

jQuery('#block-devel-switch-user').click(function(){
   jQuery('ul.links').slideToggle();
 });


 });

})(jQuery);


;
