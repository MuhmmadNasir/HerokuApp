(function($){

jQuery(document).ready(function(){

alert("welcome");



 });

})(jQuery);


;
(function($){

jQuery(document).ready(function(){

alert("welcome");



 });

})(jQuery);


;
