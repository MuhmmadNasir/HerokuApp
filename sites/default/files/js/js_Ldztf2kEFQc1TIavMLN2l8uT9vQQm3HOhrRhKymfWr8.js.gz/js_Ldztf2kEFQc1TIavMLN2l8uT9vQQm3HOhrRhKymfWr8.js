(function($){

jQuery(document).ready(function(){

alert("welcome");



 });

})(jQuery);


;
(function($){

$(document).ready(function(){

$('#block-devel-switch-user').click(function(){
   $('ul.links').slideToggle();
 });


 });

})(jQuery);


;
